package com.example.softrelic.Service;

import com.example.softrelic.Repository.PostRepository;
import com.example.softrelic.Repository.UserRepository;
import com.example.softrelic.domain.Post;
import com.example.softrelic.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PostService {
    private final UserRepository userRepository;

    private final PostRepository postRepository;
    public PostService(UserRepository userRepository, PostRepository postRepository) {
        this.userRepository = userRepository;
        this.postRepository = postRepository;}

        public Post createPost(Post post){
        return postRepository.save(post);
        }
    public Post create(Post post, Long userId) {
        Optional<User> opuser = userRepository.findById(userId);
        if (opuser.isPresent()) {
            User user = opuser.get();
            post.setUser(user);
        } else {
            return null;
        }
        return postRepository.save(post);
    }

}
